-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-04-2013 a las 16:19:31
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de datos: `encuestas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta`
--

CREATE TABLE `encuesta` (
  `id_encuesta` int(255) NOT NULL auto_increment,
  `encuesta` varchar(255) character set latin1 collate latin1_spanish_ci NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY  (`id_encuesta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `encuesta`
--

INSERT INTO `encuesta` (`id_encuesta`, `encuesta`, `id_usuario`) VALUES
(1, 'encuesta1', 0),
(2, 'encuesta2', 0),
(3, 'encuesta3', 0),
(4, 'test 1', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id_pregunta` int(255) NOT NULL auto_increment,
  `id_encuesta` int(255) NOT NULL,
  `pregunta` varchar(100) character set latin1 collate latin1_spanish_ci NOT NULL,
  `mandatory` int(11) NOT NULL,
  `condicion` int(10) NOT NULL,
  `id_tipo` int(10) NOT NULL,
  `numero_pregunta` varchar(10) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_pregunta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id_pregunta`, `id_encuesta`, `pregunta`, `mandatory`, `condicion`, `id_tipo`, `numero_pregunta`) VALUES
(4, 1, 'que edad tiene?', 1, 0, 0, '2'),
(3, 1, 'como te llamas?', 1, 0, 0, '1'),
(5, 1, 'le gustan las peliculas de terror?  ', 1, 5, 0, '3'),
(6, 1, 'que tipo de peliculas le gustan?', 1, 0, 0, '4'),
(7, 1, 'que pelicula de terror has visto ultimamente?', 1, 0, 0, '5');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id_respuesta` int(11) NOT NULL auto_increment,
  `id_pregunta` varchar(255) collate latin1_general_ci NOT NULL,
  `texto` varchar(255) collate latin1_general_ci NOT NULL,
  `condicion` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY  (`id_respuesta`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`id_respuesta`, `id_pregunta`, `texto`, `condicion`, `id_tipo`) VALUES
(1, '3', 'edad', 0, 3),
(2, '4', 'nombre', 0, 3),
(3, '5', 'si', 0, 1),
(4, '5', 'no', 0, 1),
(5, '6', 'genero', 0, 3),
(6, '7', 'reciente', 0, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL auto_increment,
  `rol` varchar(20) collate latin1_general_ci NOT NULL,
  `editar` int(11) NOT NULL,
  `crear` int(11) NOT NULL,
  `borrar` int(11) NOT NULL,
  `encuestar` int(11) NOT NULL,
  `resultados` int(11) NOT NULL,
  PRIMARY KEY  (`id_rol`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `rol`, `editar`, `crear`, `borrar`, `encuestar`, `resultados`) VALUES
(1, 'admin', 1, 1, 1, 1, 1),
(2, 'usuario', 0, 0, 0, 0, 1),
(3, 'encuestador', 0, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submissions`
--

CREATE TABLE `submissions` (
  `id_submission` int(11) NOT NULL auto_increment,
  `id_usuario` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `id_encuesta` int(11) NOT NULL,
  PRIMARY KEY  (`id_submission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `submissions`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `submitted_data`
--

CREATE TABLE `submitted_data` (
  `id_submission` int(11) NOT NULL,
  `id_pregunta` int(11) NOT NULL,
  `respuesta` varchar(100) collate latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Volcar la base de datos para la tabla `submitted_data`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_preguntas`
--

CREATE TABLE `tipos_preguntas` (
  `id_tipo` int(11) NOT NULL auto_increment,
  `tipo_respuesta` varchar(20) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_tipo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `tipos_preguntas`
--

INSERT INTO `tipos_preguntas` (`id_tipo`, `tipo_respuesta`) VALUES
(1, 'multiple 1'),
(2, 'multiple mas de 1'),
(3, 'abierta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `nombre` varchar(50) collate latin1_general_ci NOT NULL,
  `email` varchar(50) collate latin1_general_ci NOT NULL,
  `password` varchar(20) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `email`, `password`) VALUES
(1, 'oscar', 'oskar2690@hotmail.com', 'sasuke');
